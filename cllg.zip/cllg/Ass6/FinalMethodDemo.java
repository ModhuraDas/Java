abstract class Shape
{	public static float pi = 3.142f;
	protected float height;
	protected float width;

	abstract float area();
}

class Square extends Shape
{	Square(float h, float w)
	{	height = h;
		width = w;}

	final float area()  //This method cannot be overwritten 
	{	return height*width;}
}

class Rectangle extends Shape
{	Rectangle (float h, float w)
	{	height = h;
		width = w;}

	final float area()  //This method cannot be overwritten 
	{	return height*width;}
}

class Circle extends Shape
{	float radius;

	Circle(float r)
	{	radius = r;}

	final float area()  //This method cannot be overwritten 
	{	return Shape.pi*radius*radius;}
}

class FinalMethodDemo
{	public static void main(String[]args)
	{	Square sObj = new Square(5,5);
		Rectangle rObj = new Rectangle(5,7);
		Circle cObj = new Circle(2);

		System.out.println("Area of square : "+sObj.area());
		System.out.println("Area of rectangle : "+rObj.area());
		System.out.println("Area of circle : "+cObj.area());}
}


