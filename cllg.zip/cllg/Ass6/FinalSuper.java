class A
{	A(int a)
	{	System.out.println("Hiii I'm A with "+a);}
}

class B extends A
{	B(int m, int b)
	{	super(m);
		System.out.println("Hiii I'm B with "+b);}
}

class C extends B
{	C(int m, int n, int c)
	{	super(m,n);
		System.out.println("Hiii I'm C with "+c);}
}

class FinalSuper
{
	public static void main(String[]args)
	{	C obj = new C(0,1,2);}
}
