class shape
{	void draw()
	{System.out.println("drawing....");}
}

class Rectangle extends shape
{		void draw()
	{System.out.println("drawing Rectangle....");}
}

class Circle extends shape
{		void draw()
	{System.out.println("drawing Circle....");}
}

class Triangle extends shape
{		void draw()
	{System.out.println("drawing Triangle....");}
}

class poly
{	public static void main(String[]args)
	{	shape s;
		s=new Rectangle();
		s.draw();
		s=new Circle();
		s.draw();
		s=new Triangle();
		s.draw();
	}
}
