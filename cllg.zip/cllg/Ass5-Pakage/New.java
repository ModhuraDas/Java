package Mypack;

import pack.NewN; 

class C extends NewN
{	
	//void cdisplay()
	{	System.out.println("I am in different package sub class......\n");
//		System.out.println(pri);
//		System.out.println(nom);		
		System.out.println(pro);
		System.out.println(pub);}
	
/*	public int s,m,avrg,d;
	public int add(int x,int y)
	{
		return x+y;
	}

	void avg(int x,int y)
	{
		avrg=(x+y)/2;}

	void mul(int a,int b)
	{
		m=a*b;}*/
}

public class New
{	public static void main(String[]args)
	{	C cobj = new C();
		cobj.cdisplay();
		//obj.print();}
		
		System.out.println("I am in different package non-sub class......\n");
//		System.out.println(pri);
//		System.out.println(nom);		
//		System.out.println(pro);
		System.out.println(pub);
	}
}

