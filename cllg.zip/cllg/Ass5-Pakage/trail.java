package pack;

import pack.*;

public class trail
{
	public static void main(String[]args)
	{
		NewN nobj = new NewN();
		System.out.println(nobj.pub);}
}
