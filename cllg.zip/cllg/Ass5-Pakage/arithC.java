import pack.NewN;

class arithC
{
	public static void main(String[]args)
	{
		New obj = new New();
		System.out.println("Sum: " +obj.add(5,6));}         //Expected Sum:11
}
