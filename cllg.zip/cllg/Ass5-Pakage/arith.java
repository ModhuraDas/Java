package pack;

import Mypack.New;

class arith
{
	public static void main(String[]args)
	{
		New obj = new New();
		System.out.println("Sum: " +obj.add(5,6));}         //Expected Sum:11
}
