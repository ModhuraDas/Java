package pack;

public class NewN
{	//private int a=5, b=9;

	private String pri = new String("I am Private");
	protected String pro = new String("I am Protected");
	public String pub = new String("I am Public");
	String nom = new String("I am No modifier");

	void display()
	{	System.out.println("I am in same class......\n");
		System.out.println(pri);
		System.out.println(nom);		
		System.out.println(pro);
		System.out.println(pub);}
	
	

/*	public int s,m,avrg,d;
	public int add(int x,int y)
	{
		return x+y;
	}

	void avg()
	{
		System.out.println("Average: " + (a+b)/2);       //Average: 12
	}

	void mul(int a,int b)
	{
		m=a*b;}

*/
}

class A extends NewN
{	void print()
	{	System.out.println("I am in same package sub class......\n");
	///	System.out.println(pri);
		System.out.println(nom);
		System.out.println(pro);
		System.out.println(pub);}
}

class B
{	public static void main(String[]args)
	{	A obj = new A();
		obj.display();
		obj.print();

/*		System.out.println("I am in same package non-sub class......\n");
	///	System.out.println(pri);
		System.out.println(nom);
		System.out.println(pro);
		System.out.println(pub);*/
	}
}
