//To explain the concepts of mutable and immutable Strings.
import java.io.*;
import java.util.Date;

public class prg8 
{
	//This function tries to add a string "Added" to the original String object. 
	static void change(String s)
		{ 
		  s = s + " Added";
		}

	//This function appends a string "Added" to the original StringBuffer object. 
	static void change(StringBuffer s)
		{
		  s.append(" Added");
		}

	public static void main(String[] args) 
		{
		   StringBuffer sb = new StringBuffer("Value");
		   String str = "Value";
		   System.out.println("Original StringBuffer: "+sb);	
		   System.out.println("Original String: "+str+"\n\nAfter Executing change function:--");	
		   change(sb);
		   change(str);
		   System.out.println("StringBuffer: "+sb);	//Displays that StringBuffer object is mutable.
		   System.out.println("String: "+str);		//Displays that String object is immutable.
		}

}
//To illustrate the use of various String API methods.
/*import java.io.*;
import java.util.Date;
public class prg8
	{
		public static void main(String args[])throws IOException
			{
				BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
				System.out.println("Enter the text:");
				String s=in.readLine();//To create a new String object. 
				System.out.println("Operations on String:");
				System.out.println(s+" charAt 3 is: "+s.charAt(3));
				System.out.println("String "+s+" compareTo \"computer\" is: "+s.compareTo("computer"));
				System.out.println("String "+s+" equals \"computer\" is: "+s.equals("computer"));
				System.out.println("String "+s+" equalsIgnoreCase \"computer\" is: "+s.equalsIgnoreCase("computer"));
				System.out.println("String "+s+" indexof first t is: "+s.indexOf('t'));
				System.out.println("String "+s+" length is: "+s.length());
				System.out.println("String "+s+" substring(0,3) is: "+s.substring(0,3));
				System.out.println("String "+s+" toUpperCase is: "+s.toUpperCase());
				System.out.println("String "+s+" toLowerCase is: "+s.toLowerCase());
				System.out.println("String  "+s+"  trim remove spaces from ends: "+s.trim());
				Date date=new Date();
				System.out.println("Current Date toString(): "+date.toString());
				Double days=Double.valueOf("7");
				System.out.println("Double days = Double.valueOf(\"7\") \nDisplaying days="+days);
			}
	}
*/
