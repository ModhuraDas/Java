import java.util.*;
import java.text.*;
class prg20
{
    public static void main(String args[])
    {
    	// To declare an object of inbuilt GregorianCalender class
        GregorianCalendar d=new GregorianCalendar();
        
        //calling the methods of GregorianCalendar class to get system's current date
        int today = d.get(Calendar.DAY_OF_MONTH);
        int year= d.get(Calendar.YEAR);
        int month= d.get(Calendar.MONTH);//Where January = 0 - December = 11
        
        //Declaring an object if GregorianCalendar class of type Calendar class
        Calendar gc = new GregorianCalendar(year, month, 1);
        //method returns a Date object that represents this Calendar's time value
        Date startDate = new Date(gc.getTime().getTime());
        int startday=startDate.getDay();
        System.out.println("Sun\tMon\tTues\tWed\tThurs\tFri\tSat");
        int c=startday,p=0,t=1;
        int day[]=new int[7];
        int dates[][]=new int[5][7];
       
        //this array represent total number of days in each month starting from Jan to Dec
        int getdaycount[]={31,28,31,30,31,30,31,31,30,31,30,31};
       
       
        for(int i=0;i<5;i++)
        	for(int j=0;j<7;j++)
        		dates[i][j]=0;
       
        for(int i=0;i<7;i++)
        	day[i]=i;
        while(t<=getdaycount[month])
        {
            if(c<7)
            {
                dates[p][c]=t++;
                c++;
            }
            else
            {
                c=0;
                p++;
            }
        }
   
        for(int i=0;i<5;i++)
        {
            for(int j=0;j<7;j++)
            {
                if(dates[i][j]!=0)
                {
                	//date array matches with today date then print "*" along with the day
					if(dates[i][j]==today)
						System.out.print(dates[i][j]+"*"+"\t");
                    else 
                    	System.out.print(dates[i][j]+"\t");
			    }
                else
                	System.out.print(" \t");
            }
            System.out.println();
        }
       
    }
}
