import java.util.Scanner;

class employee
{
	int emp_id, salary;
	String name, desig;

	employee (String n, int sal, String d)   //Exiuctive
	{
		name=n;
		emp_id=2;
		salary=sal;
		desig=d;
	}

	employee (String a)   //Freshers
	{
		name=a;
                emp_id=1;
                salary=15000;
                desig="fershers";
	}

	employee ()   //Temp
	{
		name="Temp";
		emp_id=0;
		salary=20000;
		desig="temp";
	}

	void display()
	{
		System.out.println("\n\n");
		System.out.println("Name of the emp:\t"+name);
		System.out.println("Id of the emp:\t"+emp_id);
		System.out.println("Salary of the emp:\t"+salary);
		System.out.println("Designation of the emp:\t"+desig);
		System.out.println("\n\n");}
}

class emp
{
	public static void main(String[]args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Hii....choose your employee type first:\n1.Freshers\n2.Executive\n3.Temporary member");
		int c = sc.nextInt();
		switch(c)
		{
			case 1: System.out.println("Enter the name: \t");
				String s=sc.next();
				employee f=new employee(s);
				f.display();
				break;

			case 2: System.out.println("Enter the name: \t");
				String s1=sc.next();				
				System.out.println("Enter the salary: \t");
				int sal=sc.nextInt();
				System.out.println("Enter the designation: \t");
				String d=sc.next();

				employee e=new employee(s1,sal,d);
				e.display();
				break;
			

			case 3: employee t=new employee();
				System.out.println(t.name);

				t.display();
				break;

		}

//		f.display();
//		e.display();
//		t.display();
	}
}
