class com
{
	public static void main(String[] args)
	{
		System.out.println("Hiii " + args[1]);
	}

}
