import java.lang.StringBuffer;

class A
{	String s= new String("Dipika Padukon");
	StringBuilder s2 = new StringBuilder("Priyanka Chopra ");
	String s1= new String("Alia Bhaat");

	void display()
	{	System.out.println("charAt(0)......... " + s.charAt(0));	//Expected D
		System.out.println("compareTo()......... " + s.compareTo(s1));	//Expected +ve
		System.out.println("equals()......... " + s.equals(s1));	//Expected false
		System.out.println("equalsIgnoreCase()......... " + s.equalsIgnoreCase(s1));	//Expected false
		System.out.println("indexOf()......... " + s.indexOf('k'));	//Expected 4
		System.out.println("length()......... " + s.length());	//Expected 14
		System.out.println("substring()......... " + s.substring(3,12));	//Expected ika Paduk
		System.out.println("toCharArray()......... " + s.charAt(0));	//Expected D
		System.out.println("toLowerCase()......... " + s.charAt(0));	//Expected D
		System.out.println("toString()......... " + s.charAt(0));	//Expected D
		System.out.println("toUpperCase()......... " + s.charAt(0));	//Expected D
		System.out.println("trim()......... " + s.charAt(0));	//Expected D
		System.out.println("valueOf()......... " + s.charAt(3));	//Expected p
		System.out.println("");	
		System.out.println("---------------------------");
		System.out.println("");
		System.out.println("append()......... " + s2.append(true));	//Expected Dipika Padukon true
		System.out.println("capacity()......... " + s2.capacity());	//Expected D
		System.out.println("charAt()......... " + s.charAt(5));	//Expected D
		System.out.println("delete()......... " + s2.delete(2,5));	//Expected Prnka Chopra true
		System.out.println("deleteCharAt()......... " + s2.deleteCharAt(6));	//Expected D
		s2.ensureCapacity(30);
		System.out.println("ensureCapacity()......... " + s2.capacity());}	//Expected D
		//System.out.println("length()......... " + s.charAt(0));}	//Expected D
}

class FinalStrbuf
{	public static void main(String[]args)
	{	A obj = new A();
		obj.display();}}
