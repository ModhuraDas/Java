class A
{
	int a;
	float b;
	String c;
}


class test
{
	public static void main(String[]args)
	{
		A obj = new A();
		System.out.println(getNativeSize(ClassA));
	}
}
